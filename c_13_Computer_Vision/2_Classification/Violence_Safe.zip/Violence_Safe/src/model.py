import torch
import torch.nn as nn
import torchvision.models as models
from utils import Bottleneck
from collections import namedtuple
from torchvision.datasets import ImageFolder
import torchvision.transforms as transforms

path_train='./data/train'
transformations = transforms.Compose([transforms.Resize((256, 256)), transforms.ToTensor()])

dataset = ImageFolder(path_train, transform = transformations)

class Resnet(nn.Module):
    def __init__(self,config,output_dim):
        super().__init__()

        block, n_blocks, channels=config
        # self.quant = torch.quantization.QuantStub()
        self.in_channels = channels[0]
        assert len(n_blocks) == len(channels) ==4

        self.conv1=nn.Conv2d(3,self.in_channels,kernel_size=7,stride=2,padding=3,bias=False)
        self.bn1=nn.BatchNorm2d(self.in_channels)
        self.relu=nn.ReLU(inplace=True)
        self.maxpool=nn.MaxPool2d(kernel_size=3,stride=2, padding=1)

        self.layer1=self._make_layer(block,n_blocks[0],channels[0])
        self.layer2=self._make_layer(block,n_blocks[1],channels[1],stride=2)
        self.layer3=self._make_layer(block,n_blocks[2],channels[2],stride=2)
        self.layer4=self._make_layer(block,n_blocks[3],channels[3],stride=2)
        self.avgpool=nn.AdaptiveAvgPool2d((1,1))
        # self.dequant = torch.quantization.DeQuantStub()
        self.fc=nn.Linear(self.in_channels,output_dim)

    def _make_layer(self,block,n_blocks,channels,stride=1):
        layers=[]

        if self.in_channels != block.expansion*channels:
            downsample=True
        else:
            downsample=False

        layers.append(block(self.in_channels,channels,stride,downsample))

        for i in range(1,n_blocks):
            layers.append(block(block.expansion*channels,channels))

        self.in_channels=block.expansion*channels

        return nn.Sequential(*layers)

    def forward(self,x):
        # x=self.quant(x)
        x=self.conv1(x)
        x=self.bn1(x)
        x= self.relu(x)
        x=self.maxpool(x)

        x=self.layer1(x)
        x=self.layer2(x)
        x=self.layer3(x)
        x=self.layer4(x)

        x=self.avgpool(x)
        # x=self.dequant(x)
        x=x.view(x.shape[0],-1)
        x=self.fc(x)

        return x
class Resnet50(nn.Module):
    def __init__(self):
        super().__init__()
        # Use a pretrained model
        self.network = models.resnet50(pretrained=True)
        # Replace last layer
        num_ftrs = self.network.fc.in_features
        self.network.fc = nn.Linear(num_ftrs, len(dataset.classes))
    
    def forward(self, xb):
        return torch.sigmoid(self.network(xb))
    # def save(self):
    


def resnet50(num_classes, pretrained=False):
    
    if pretrained:
        # model_urls='https://download.pytorch.org/models/resnet50-19c8e357.pth'
        # model.load_state_dict(model_zoo.load_url(model_urls, model_dir='.'), strict=False)
        model=Resnet50()
    else:
        ResNetConfig = namedtuple('ResNetConfig', ['block', 'n_blocks', 'channels'])
        resnet50_config = ResNetConfig(block = Bottleneck,
                               n_blocks = [3, 4, 6, 3],
                               channels = [64, 128, 256, 512])
        model = Resnet(resnet50_config,output_dim=num_classes)
    return model