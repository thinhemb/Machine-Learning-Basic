import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
import os
import torch.nn.functional as F

def plot_accuracies(history):
    val_acc = [x['val_acc'] for x in history]
    train_acc = [x['train_acc'] for x in history]
    
    plt.plot(train_acc ,label='train_acc',marker = 'o',color='r')
    plt.plot(val_acc,label='val_acc',marker = 'o',color='b')
    
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    plt.title(' Accuracy')
    plt.savefig('./image/Accuracies.jpg', dpi=300)
    
def plot_loss(history):
    train_losses = [x.get('train_loss') for x in history]
    val_losses = [x['val_loss'] for x in history]
    plt.plot(train_losses,label='train_loss',marker = 'o',color='g')
    plt.plot(val_losses,label='val_loss',marker = 'o',color='y')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title(' Loss')
    plt.savefig('./image/Loss.jpg', dpi=300)
    
def get_predictions(model, iterator,device):

    model.eval()

    images = []
    labels = []
    probs = []

    with torch.no_grad():

        for (x, y) in iterator:

            x = x.to(device)

            y_pred = model(x)

            y_prob = F.softmax(y_pred, dim = -1)
            top_pred = y_prob.argmax(1, keepdim = True)

            images.append(x.cpu())
            labels.append(y.cpu())
            probs.append(y_prob.cpu())

    images = torch.cat(images, dim = 0)
    labels = torch.cat(labels, dim = 0)
    probs = torch.cat(probs, dim = 0)

    return images, labels, probs

def plot_confusion_matrix(labels, pred_labels, classes):
    
    fig = plt.figure(figsize = (12, 12))
    ax = fig.add_subplot(1, 1, 1)
    cm = confusion_matrix(labels, pred_labels)
    cm = ConfusionMatrixDisplay(cm, display_labels = classes)
    cm.plot(values_format = 'd', cmap = 'Blues', ax = ax)
    fig.delaxes(fig.axes[1]) #delete colorbar
    plt.xticks(rotation = 90)
    plt.xlabel('Predicted Label', fontsize = 20)
    plt.ylabel('True Label', fontsize = 20)
    plt.savefig('./image/confusion_matrix.jpg', dpi=300)

def Confusion_matrix(model, path_val,val_dl,device):
    classes = os.listdir(path_val)
    images, labels, probs = get_predictions(model,val_dl ,device)
    pred_labels = torch.argmax(probs, 1)
    plot_confusion_matrix(labels, pred_labels, classes)
