import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F

def to_device(data, device):
    """Move tensor(s) to chosen device"""
    if isinstance(data, (list,tuple)):
        return [to_device(x, device) for x in data]
    return data.to(device, non_blocking=True)

class DeviceDataLoader():
    """Wrap a dataloader to move data to a device"""
    def __init__(self, dl, device):
        self.dl = dl
        self.device = device
        
    def __iter__(self):
        """Yield a batch of data after moving it to device"""
        for b in self.dl: 
            yield to_device(b, self.device)

    def __len__(self):
        """Number of batches"""
        return len(self.dl)

        
def accuracy(outputs, labels):
    _, preds = torch.max(outputs, dim=1)
    return torch.tensor(torch.sum(preds == labels).item() / len(preds))

    
def validation_step(model,batch):
    images, labels = batch 
    out = model(images)                    # Generate predictions
    loss = F.cross_entropy(out, labels)   # Calculate loss
    acc = accuracy(out, labels)           # Calculate accuracy
    return {'val_loss': loss.detach(), 'val_acc': acc}
        
def validation_epoch_end(outputs):
    batch_losses = [x['val_loss'] for x in outputs]
    epoch_loss = torch.stack(batch_losses).mean()   # Combine losses
    batch_accs = [x['val_acc'] for x in outputs]
    epoch_acc = torch.stack(batch_accs).mean()      # Combine accuracies
    return {'val_loss': epoch_loss.item(), 'val_acc': epoch_acc.item()}
    
def epoch_end(result):
    print("  Train_loss: {:.4f}, val_loss: {:.4f}, train_acc: {:.4f}, val_acc: {:.4f}".format(
         result['train_loss'], result['val_loss'],result['train_acc'], result['val_acc']))

class Bottleneck(nn.Module):
    expansion = 4
    def __init__(self,in_channels, out_channels,stride=1,downsample=False):
        super().__init__()

        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1,stride=stride, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)

        self.conv2= nn.Conv2d(out_channels, out_channels,stride=1,kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)

        self.conv3= nn.Conv2d(out_channels, out_channels*self.expansion,stride=1,kernel_size=1, padding=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels*self.expansion)

        self.relu= nn.ReLU(inplace=True)

        if downsample:
            conv=nn.Conv2d(in_channels,out_channels*self.expansion,kernel_size=1,stride=stride,bias=False)
            bn=nn.BatchNorm2d(out_channels*self.expansion)
            downsample=nn.Sequential(conv,bn)
        else:
            downsample=None
        self.downsample = downsample

    def forward(self,x):
        residual =x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)
        if self.downsample is not None:
            residual=self.downsample(residual)

        out+=residual
        out=self.relu(out)
        return out

