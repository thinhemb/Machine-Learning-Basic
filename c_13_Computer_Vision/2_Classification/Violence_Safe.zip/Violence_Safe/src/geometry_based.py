import cv2
import os
path_train = "/home/thinh-do/Workspace/Violence/data/train/safe"
path_train_born="/home/thinh-do/Workspace/Violence/data/train/add/"
def load_data(path):
    
    for name_image in os.listdir(path_train):
        path_image = path_train +"/"+ name_image
        image = cv2.imread(path_image)
        quadrant_turn = [90,180,270] #góc quay
        os.chdir(path_train_born)
        count=0
        try:
            (h, w, d) = image.shape
            center = (w // 2, h // 2)
            
            for j in quadrant_turn:
                check = cv2.getRotationMatrix2D(center, j , 1.0) 
                    #lấy tâm, góc và tỷ lệ làm đối số và xuất ra ma trận biến đổi
                img = cv2.warpAffine(image, check, (w, h)) #quay ảnh
                count+=1
                filename=path_train_born+str(count)+name_image
                print(filename)
                cv2.imwrite(filename, img)
            count+=1
        except:
            continue
            # h: height, w: wight
            

load_data(path_train)