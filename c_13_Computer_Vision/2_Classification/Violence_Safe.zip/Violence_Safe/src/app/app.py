from flask import Flask, render_template,request
import torch
from PIL import Image
from torchvision.datasets import ImageFolder
import torchvision.transforms as transforms
import os
import cv2




app= Flask(__name__)
device='cpu'
path_train='./data/train'
transformations = transforms.Compose([transforms.Resize((256, 256)), transforms.ToTensor()])
transform = transforms.ToTensor()
dataset = ImageFolder(path_train, transform = transformations)


def to_device(data, device):
    """Move tensor(s) to chosen device"""
    if isinstance(data, (list,tuple)):
        return [to_device(x, device) for x in data]
    return data.to(device, non_blocking=True)


def predict_image(img, model):
    image= transform(img)
    xb = to_device(image.unsqueeze(0), device)

    # Get predictions from model    
    yb = model(xb)
    # Pick index with highest probability
    prob, preds  = torch.max(yb, dim=1)
    # Retrieve the class label
    return dataset.classes[preds[0].item()]


@app.route('/',methods=['GET'])
def hello():
    return render_template('index.html')


@app.route('/',methods=['POST'])
def predict():
    
    imagefile=request.files['imagefile']
    image_path='./data/' + imagefile.filename
    # cv2.imwrite(image_path, imagefile)
    with open('./data/',"wb") as f:
        f.write((image_path).getbuffer())
    # imagefile.save(image_path)
    model_path='../model_last.pth'
    model=torch.load(model_path,map_location='cpu')
    image=Image.open(image_path)
    output=predict_image(image,model)
    
    return render_template("index.html",prediction=output)



if __name__=='__main__':
    app.run(port=3000,debug=True)
