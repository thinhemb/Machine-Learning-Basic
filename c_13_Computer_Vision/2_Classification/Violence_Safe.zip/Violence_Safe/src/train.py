import torch
import torch.nn.functional as F
from torchvision.datasets import ImageFolder
import torchvision.transforms as transforms
import os
from model import resnet50
from torch.utils.data.dataloader import DataLoader
import pandas as pd
from plot import plot_accuracies,Confusion_matrix,plot_loss

from utils import Bottleneck,DeviceDataLoader,to_device,validation_step,validation_epoch_end,epoch_end,accuracy


path_train='./data/train'
path_val='./data/val'
device =torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

classes = os.listdir(path_train)


transformations = transforms.Compose([transforms.Resize((256, 256)), transforms.ToTensor()])

dataset_train = ImageFolder(path_train, transform = transformations)
dataset_val = ImageFolder(path_val, transform = transformations)



train_dl = DataLoader(dataset_train, batch_size=16, shuffle = True, num_workers = 2, pin_memory = True)

val_dl = DataLoader(dataset_val, batch_size=16,  num_workers = 2, pin_memory = True)

train_dl = DeviceDataLoader(train_dl, device)
val_dl = DeviceDataLoader(val_dl, device)

model=resnet50(num_classes=2,pretrained=True)



to_device(model, device)



@torch.no_grad()
def evaluate(model, val_dl):
    model.eval()
    
    outputs = [validation_step(model,batch) for batch in val_dl]
    return validation_epoch_end(outputs)

def fit(epochs, lr, model, train_dl, val_dl):
    history = []
    optimizer = torch.optim.SGD(model.parameters(), lr)
    for epoch in range(1,epochs+1):
        # Training Phase 
        print('Epoch {}/{}'.format(epoch, epochs))
        model.train()
        train_losses = []
        train_acc=[]
        
        for images, labels in train_dl:
            images = to_device(images, device)
            out =  model(images)             # Generate predictions
            loss = F.cross_entropy(out, labels)
            acc_train = accuracy(out, labels)           # Calculate accuracy
            train_losses.append(loss)
            train_acc.append(acc_train)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
        # Validation phase
        result = evaluate(model, val_dl)
        result['train_loss'] = torch.stack(train_losses).mean().item()
        result['train_acc'] = torch.stack(train_acc).mean().item()
        epoch_end(result)
        history.append(result)
        if epoch==1:
            torch.save(model, './model1.pth')
    torch.save(model, '/./model_last.pth')
    
    return history

num_epochs =50
lr = 5.5e-5
history = fit(num_epochs, lr, model, train_dl, val_dl)
H = pd.DataFrame(history)

H.to_csv("/content/drive/MyDrive/Violence/acc.csv")
evaluate(model, val_dl)

plot_accuracies(history)
plot_loss(history)
Confusion_matrix(model, path_val,val_dl,device)
