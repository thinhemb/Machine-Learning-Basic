import torch
import torchvision
from torch.utils.data import Dataset 
import logging
import glob
import numpy as np
import cv2 

logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

class DatasetLoader(Dataset):

    def __init__(self,data_path,image_size:int =256)->None:
        super(DatasetLoader).__init__()
        self.data_path = data_path
        self.image_size = image_size
        self._load_dataset(data_path=self.data_path)
    
    def __len__(self):
        return len(self.dataframe)
    

    def __getitem__(self,index):
        cur_image_path, cur_label=self.dataframe[index]
        image=cv2.imread(cur_image_path)
        Image=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
        image=cv2.resize(image,(self.image_size,self.image_size),cv2.INTER_CUBIC)
        image=image.transpose(2,0,1).astype(np.float32)
        return image,cur_label
        
        #Load dataset
    def _load_dataset(self, data_path):
        logger.info("Loading data from: {}".format(data_path))
        self.dataframe=[]
        all_images_path= glob.glob(data_path + '*/*.*.jpg')
        for image_path in all_images_path:
            label=image_path.split('/')[-2]
            if 'Glass' in label:
                type_image=0
            elif 'Metal' in label:
                type_image=2
            elif 'Organic' in label:
                type_image=5
            elif 'Paper' in label:
                type_image=1
            elif 'Pin' in label:
                type_image=4
            elif 'Plastic' in label:
                type_image=3

            self.dataframe.append([image_path,type_image])
