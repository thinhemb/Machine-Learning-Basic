



import matplotlib.pyplot as plt # for plotting
import numpy as np # for transformation
from torch.utils.data.dataloader import DataLoader
import torchvision.models as models
from dataset import DatasetLoader
import torch # PyTorch package
import torchvision # load datasets
import torchvision.transforms as transforms # transform data (để thực hiện chuyển đổi trên dữ liệu hình ảnh)
import torch.nn as nn # basic building block for neural neteorks (là để xây dựng mạng nơ-ron)
import torch.nn.functional as f # import convolution functions like Relu (nhập các chức năng như Relu)
import torch.optim as optim # optimzer
from tqdm import tqdm
import os
from poutyne.framework import Model




device =torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')


path='./Data/trash_detection/Data/train'
val_path='./Data/trash_detection/Data/test'


image_size =256

num_epochs=16
batch_size=32
lr=1e-5

# logger = logging.getLogger()


train_ds=DatasetLoader(path,image_size)
train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle = True, num_workers = 2, pin_memory = True)

val_ds=DatasetLoader(path,image_size)
val_dl = DataLoader(val_ds, batch_size=batch_size, shuffle = True, num_workers = 2, pin_memory = True)



model = models.resnet50(pretrained=True).to(device)
optimizer = optim.Adam(model.parameters(), lr=lr)
loss_function = nn.CrossEntropyLoss()
model = Model(model, optimizer, loss_function, batch_metrics=['accuracy'])
model.to(device)

model.fit_generator(train_dl, val_dl, epochs=num_epochs)
    # Test
test_loss, test_acc = model.evaluate_generator(val_dl)
print(f'Test:\n\tLoss: {test_loss: .3f}\n\tAccuracy: {test_acc: .3f}')



if not os.path.isdir(f'{SAVE_DIR}'):
    os.makedirs(f'{SAVE_DIR}')
SAVE_DIR = "./trash_detection/"
MODEL_SAVE_PATH = os.path.join(SAVE_DIR, "my_model.pt")
torch.save(model, MODEL_SAVE_PATH)
