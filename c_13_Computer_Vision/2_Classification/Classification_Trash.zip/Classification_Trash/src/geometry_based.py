import cv2
import os
path_train = "./data/train/"
path_train_born="./data/train_born/"
def load_data(path):
    for folder in os.listdir(path): 
        path_folder = path + folder
        count=0
        for name_image in os.listdir( path_folder):
            path_image = path_folder +"/"+ name_image
            image = cv2.imread(path_image)
            quadrant_turn = [45,90,135,180,270] #góc quay
            os.chdir(path_train_born+folder)
            try:
                (h, w, d) = image.shape
                center = (w // 2, h // 2)
                for j in quadrant_turn:
                    check = cv2.getRotationMatrix2D(center, j , 1.0) 
                    #lấy tâm, góc và tỷ lệ làm đối số và xuất ra ma trận biến đổi
                    img = cv2.warpAffine(image, check, (w, h)) #quay ảnh
                    count+=1
                    filename=folder+"."+str(count)+".jpg"
                    print(filename)
                    cv2.imwrite(filename, img)
            except:
                continue
            # h: height, w: wight
            

load_data(path_train)
