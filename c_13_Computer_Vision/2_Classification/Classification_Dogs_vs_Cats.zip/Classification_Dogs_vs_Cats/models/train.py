import torch
import torchvision.models as models
from dataset import DatasetLoader
from torch.utils.data import DataLoader
from CLASSIFICATION_DOGS_VS_CATS import DataLoader
logger=logging.Logger(__name__)
#logger.setLevel(logging.DEBUG)
device =torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
path= './model_dog_vs_cat/train'
image_size =224
num_epochs=50
batch_size=16
lr=1e-4


model=models.resnet101(num_classes=2).to(device)

train_data=DatasetLoader(path, image_size)
#train_data=DatasetLoader('./model_dog_vs_cat/test',image_size)
train_loader=DataLoader(train_data,batch_size=batch_size,shuffle=True)
#val_loader=DataLoader(val_data,batch_size=batch_size,shuffle=True)

optimizer=optim.Adam(model.parameters(),lr=lr)



for i in range(num_epochs):
    logger.info('Training on epoch: {}'.format(i+1))
    model.train()
    loss_per_epoch=0
    acc=0
    for batch_image,y_trutch in tqdm.tqdm(train_loader,desc='Training'):
        batch_image.to(device),y_truth.to(device)
        optimizer.zero_grad()
        Y_pred=model.forward(batch_image)  #feed dorward
        loss =f.cross_entropy(y_pred,y_truth)
        loss_per_epoch+loss
        #acc+=torch.sum(y_truth==y_pred)
        logger.info('hello')
        loss.backward()
        optimizer.step()
