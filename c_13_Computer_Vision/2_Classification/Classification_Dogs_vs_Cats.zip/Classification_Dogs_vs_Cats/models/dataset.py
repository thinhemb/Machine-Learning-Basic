
import torch
import torchvision
from torch.utils.data import Dataset 
import logging
import glob
import numpy as np
import cv2 


logger=logging.getLogger()
logger.setLevel(logging.DEBUG)


class DatasetLoader(Dataset):

    def __init__(self, name :str ,data_path: str,image_size: int =224)->None:
        super(DatasetLoader).__init__()
        self.data_path = data_path
        self.image_size = 224
        self.__load_dataset(self,data_path)
    
    def __len__(self):
        return len(self.all_files_and_class)
    
    def __getitem__(self,index):
        cur_image_path,cur_label = self.all_files_and_class[index]
        image=cv2.imread(cur_image_path)
        image=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
        image=cv2.resize(image,(self.image_size,self.image_size),cv2.INTER_CUBIC)
        image-image.transpose(2,0,1).astype(np.float32)
        return image,cur_label
        
    def __load_dataset(self,data_path):
        logger.info("Loading data from: {}".format(data_path))
        self.all_files_and_class=[]
        all_images_path =glob.glob(data_path+'*.jpg')
        for image_path in all_images_path:
            label=image_path.split('/')[-1]
            if 'dog' in label:
                type_image=1
            else :
                type_image=0
            
            self.all_files_and_class.append(image_path,type_image)
